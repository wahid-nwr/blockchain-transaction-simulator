import { describe, it, expect, vi } from 'vitest';
import { LedgerService } from '../../src/services/ledger.service.js';

describe('LedgerService', () => {
    function createRepositoryMock() {
        return {
            create: vi.fn(),
            attachHash: vi.fn(),
            confirm: vi.fn(),
            markFailed: vi.fn(),
        };
    }

    it('should create pending transaction', async () => {
        const repository = createRepositoryMock();
        repository.create.mockResolvedValue({
            id: 'tx-1',
            status: 'PENDING',
        });

        const service = new LedgerService(repository as any);

        const result = await service.createPending({
            tenantId: 'tenant-1',
            tokenId: 'token-1',
            fromWalletId: 'wallet-1',
            toWalletId: 'wallet-2',
            amount: 100n,
        });

        expect(repository.create).toHaveBeenCalledWith({
            tenantId: 'tenant-1',
            tokenId: 'token-1',
            fromWalletId: 'wallet-1',
            toWalletId: 'wallet-2',
            amount: 100n,
            status: 'PENDING',
        });

        expect(result.status).toBe('PENDING');
    });

    it('should attach blockchain hash', async () => {
        const repository = createRepositoryMock();

        await new LedgerService(repository as any).attachHash('tx-1', '0xabc');

        expect(repository.attachHash).toHaveBeenCalledWith('tx-1', '0xabc');
    });

    it('should confirm transaction converting block number', async () => {
        const repository = createRepositoryMock();

        await new LedgerService(repository as any).confirm('0xhash', {
            blockNumber: 100n,
            gasUsed: 50000n,
        });

        expect(repository.confirm).toHaveBeenCalledWith('0xhash', {
            blockNumber: 100,
            gasUsed: 50000n,
        });
    });

    it('should mark transaction failed', async () => {
        const repository = createRepositoryMock();

        await new LedgerService(repository as any).markFailed('tx-1');

        expect(repository.markFailed).toHaveBeenCalledWith('tx-1');
    });
});
